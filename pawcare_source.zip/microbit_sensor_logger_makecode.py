# MakeCode Python: 소리·빛 센서만 확인하는 로컬 기록 예제 (micro:bit V2 권장)
# 이 파일은 단독 센서 시험용입니다. 재난 라디오 수신까지 한꺼번에 쓰려면
# microbit_disaster_receiver_makecode.py 하나만 RoboDog 탑재 micro:bit에 넣으세요.

datalogger.set_column_titles("time_ms", "segment", "phase", "sound", "light")

speed_cm_per_s = 23
turn_time_per_degree = 2.80 / 180
course = [10, 100, 90, 30, 90, 100, -90, 30, -90, 100, 90, 30, 90, 100, -90, 30, -90, 100]

segment_end_times_ms = []
segment_phases = []
cumulative = 0
for i in range(len(course)):
    value = course[i]
    if (i + 1) % 2 == 1:
        duration_s = abs(value) * turn_time_per_degree
        phase_label = "TURN"
    else:
        duration_s = value / speed_cm_per_s
        phase_label = "STRAIGHT"
    cumulative += duration_s * 1000
    segment_end_times_ms.append(cumulative)
    segment_phases.append(phase_label)


def get_segment_info(t):
    for i in range(len(segment_end_times_ms)):
        if t < segment_end_times_ms[i]:
            return i + 1, segment_phases[i]
    return len(segment_end_times_ms) + 1, "DONE"


# A 버튼을 누를 때 새 기록을 시작합니다.
start_time = -1


def on_button_pressed_a():
    global start_time
    datalogger.delete_log()
    start_time = input.running_time()
    basic.show_icon(IconNames.YES)


input.on_button_pressed(Button.A, on_button_pressed_a)


def on_forever():
    if start_time >= 0:
        elapsed = input.running_time() - start_time
        segment, phase = get_segment_info(elapsed)
        sound_value = input.sound_level()
        light_value = input.light_level()

        # 소리·빛 값은 micro:bit 내부 DataLogger에만 기록합니다.
        datalogger.log(
            datalogger.create_cv("time_ms", elapsed),
            datalogger.create_cv("segment", segment),
            datalogger.create_cv("phase", phase),
            datalogger.create_cv("sound", sound_value),
            datalogger.create_cv("light", light_value)
        )
        basic.show_number(sound_value)
    else:
        basic.show_icon(IconNames.SMALL_DIAMOND)
    basic.pause(500)


basic.forever(on_forever)
